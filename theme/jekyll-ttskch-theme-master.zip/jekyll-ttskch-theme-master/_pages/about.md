---
layout: page
title: About
permalink: /about/
order: 1
share: false
---

[TtskchTheme](https://github.com/ttskch/jekyll-ttskch-theme) is a free and open-source theme for [Jekyll](http://jekyllrb.com/), licensed under the MIT License.

Enjoy! :smiley:
